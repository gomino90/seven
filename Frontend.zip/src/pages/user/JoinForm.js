const JoinForm = () => {
  return <div>회원가입</div>;
};

export default JoinForm;
